Simple Web Music Player
======================

Project contents:
- index.html
- styles.css
- script.js

How to use:
1. Extract the zip and open `index.html` in a modern browser.
2. Use "Add audio files" to upload local MP3/OGG files (you can also drag & drop files onto the page).
3. Play/pause, go next/previous, control volume and seek.
4. Search by title/artist using the search box.
5. Filter by category using the dropdown. To assign a category to a track, double-click its entry and type a category name (e.g., rock, pop).

Notes for submission:
- This is a client-side project (HTML/CSS/JS). No server required.
- For the internship, include this project folder (or a ZIP of it) and a short report explaining features implemented:
  * Playlist support (multiple files)
  * Search and category filter
  * Play, pause, next, previous, seek, volume control
  * Drag & drop & file upload support

You can add your own sample audio files into the directory and upload via the UI.

