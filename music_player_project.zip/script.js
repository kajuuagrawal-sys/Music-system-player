// Simple playlist-based music player with search, categories, and controls
const audio = document.getElementById('audio');
const playPauseBtn = document.getElementById('playPauseBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const volume = document.getElementById('volume');
const seekBar = document.getElementById('seekBar');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');
const playlistEl = document.getElementById('playlist');
const fileInput = document.getElementById('fileInput');
const searchInput = document.getElementById('search');
const categoryFilter = document.getElementById('categoryFilter');
const currentTitle = document.getElementById('current-title');
const currentArtist = document.getElementById('current-artist');

let tracks = []; // {id, title, artist, fileUrl, category, duration}
let currentIndex = -1;
let isPlaying = false;

// Utils
function formatTime(sec){
  if(!sec || isNaN(sec)) return '00:00';
  const m = Math.floor(sec/60).toString().padStart(2,'0');
  const s = Math.floor(sec%60).toString().padStart(2,'0');
  return `${m}:${s}`;
}

function renderPlaylist(){
  playlistEl.innerHTML = '';
  const q = searchInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;

  tracks.forEach((t, i) => {
    if(q && !(t.title.toLowerCase().includes(q) || (t.artist && t.artist.toLowerCase().includes(q)))) return;
    if(cat && t.category !== cat) return;

    const li = document.createElement('li');
    const meta = document.createElement('div');
    meta.className='track-meta';
    const info = document.createElement('div');
    info.innerHTML = `<div class="track-title">${t.title}</div><div class="track-category">${t.artist || 'Unknown'} • ${t.category || 'Uncategorized'}</div>`;
    meta.appendChild(info);

    const actions = document.createElement('div');
    actions.className='track-actions';
    const playBtn = document.createElement('button');
    playBtn.textContent = (i===currentIndex && isPlaying) ? '⏸' : '▶️';
    playBtn.onclick = () => { playTrack(i); }
    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remove';
    removeBtn.onclick = () => { removeTrack(i); }

    actions.appendChild(playBtn);
    actions.appendChild(removeBtn);

    li.appendChild(meta);
    li.appendChild(actions);
    playlistEl.appendChild(li);
  });
}

function addFiles(files){
  Array.from(files).forEach(file => {
    const id = Date.now() + Math.random();
    const url = URL.createObjectURL(file);
    // attempt to parse name "artist - title.ext" pattern
    let title = file.name;
    let artist = '';
    const nameOnly = file.name.replace(/\.[^/.]+$/, "");
    const parts = nameOnly.split(' - ');
    if(parts.length>=2){
      artist = parts[0].trim();
      title = parts.slice(1).join(' - ').trim();
    } else {
      title = nameOnly;
    }
    tracks.push({id, title, artist, fileUrl: url, category: '', fileObject: file});
    // load metadata to get duration
    const a = new Audio();
    a.src = url;
    a.addEventListener('loadedmetadata', () => {
      const track = tracks.find(x=>x.id===id);
      if(track) track.duration = a.duration;
      renderPlaylist();
    });
  });
  renderPlaylist();
}

// Playback
function playTrack(idx){
  if(idx < 0 || idx >= tracks.length) return;
  const t = tracks[idx];
  currentIndex = idx;
  audio.src = t.fileUrl;
  currentTitle.textContent = t.title;
  currentArtist.textContent = t.artist || '';
  audio.play();
  isPlaying = true;
  playPauseBtn.textContent = '⏸';
  renderPlaylist();
}

playPauseBtn.onclick = () => {
  if(currentIndex === -1 && tracks.length>0){
    playTrack(0); return;
  }
  if(audio.paused){
    audio.play();
    isPlaying = true;
    playPauseBtn.textContent = '⏸';
  } else {
    audio.pause();
    isPlaying = false;
    playPauseBtn.textContent = '▶️';
  }
}

prevBtn.onclick = () => {
  if(tracks.length===0) return;
  let idx = currentIndex - 1;
  if(idx < 0) idx = tracks.length - 1;
  playTrack(idx);
}
nextBtn.onclick = () => {
  if(tracks.length===0) return;
  let idx = currentIndex + 1;
  if(idx >= tracks.length) idx = 0;
  playTrack(idx);
}

audio.ontimeupdate = () => {
  if(!isNaN(audio.duration)){
    const percent = (audio.currentTime / audio.duration) * 100;
    seekBar.value = percent;
    currentTimeEl.textContent = formatTime(audio.currentTime);
    durationEl.textContent = formatTime(audio.duration);
  }
}
seekBar.oninput = () => {
  if(isNaN(audio.duration)) return;
  const pct = seekBar.value / 100;
  audio.currentTime = audio.duration * pct;
}

volume.oninput = () => {
  audio.volume = volume.value;
}

audio.onended = () => {
  nextBtn.onclick();
}

function removeTrack(idx){
  if(idx < 0 || idx >= tracks.length) return;
  const wasCurrent = (idx === currentIndex);
  // revoke object URL
  if(tracks[idx] && tracks[idx].fileUrl) URL.revokeObjectURL(tracks[idx].fileUrl);
  tracks.splice(idx,1);
  if(wasCurrent){
    audio.pause();
    audio.src = '';
    currentIndex = -1;
    isPlaying = false;
    playPauseBtn.textContent = '▶️';
    currentTitle.textContent = 'No track selected';
    currentArtist.textContent = '';
  } else if(idx < currentIndex){
    currentIndex--;
  }
  renderPlaylist();
}

// file input and drag-drop
fileInput.onchange = (e) => addFiles(e.target.files);

document.addEventListener('dragover', e=> e.preventDefault());
document.addEventListener('drop', e=>{
  e.preventDefault();
  if(e.dataTransfer && e.dataTransfer.files){
    addFiles(e.dataTransfer.files);
  }
});

// search and filter
searchInput.oninput = () => renderPlaylist();
categoryFilter.onchange = () => {
  // when filter changes, set category for selected items (optional)
  renderPlaylist();
}

// simple UI: allow category assign by double-clicking a track entry
playlistEl.addEventListener('dblclick', (ev) => {
  const li = ev.target.closest('li');
  if(!li) return;
  const nodes = Array.from(playlistEl.children);
  const idx = nodes.indexOf(li);
  if(idx===-1) return;
  const cat = prompt('Set category (e.g., pop, rock, classical, hiphop). Leave empty to clear.');
  if(cat!==null){
    tracks[idx].category = cat.trim().toLowerCase();
    renderPlaylist();
  }
});

// Initialize
renderPlaylist();
